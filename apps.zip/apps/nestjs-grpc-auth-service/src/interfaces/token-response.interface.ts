export interface ITokenResponse {
  status: number;
  data?: string;
  message: string;
}
