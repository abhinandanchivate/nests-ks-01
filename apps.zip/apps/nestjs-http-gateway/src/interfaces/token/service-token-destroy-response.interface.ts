export interface IServiceTokenDestroyResponse {
  status: number;
  message: string;
  errors: { [key: string]: any };
}
