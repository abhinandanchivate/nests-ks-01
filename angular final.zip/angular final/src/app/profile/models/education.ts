export class Education {
  school: string;
  degree: string;
  fieldofstudy: string;
  from: string;
  to: string;
  current: string;
  description: string;
}
