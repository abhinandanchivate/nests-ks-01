export class Experience {
  title: string;
  company: string;
  location: string;
  from: string;
  to: string;
  current: string;
  description: string;
}
