import { Experience } from './experience';

describe('Experience', () => {
  it('should create an instance', () => {
    expect(new Experience()).toBeTruthy();
  });
});
