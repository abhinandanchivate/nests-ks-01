export const userSignupRequestFailShortPw = {
  email: 'test@denrox.com',
  password: 'test1',
};

export const userSignupRequestFailNoPw = {
  email: 'test@denrox.com',
};

export const userSignupRequestFailInvalidEmail = {
  email: 'testdenrox.com',
  password: 'test11',
};
