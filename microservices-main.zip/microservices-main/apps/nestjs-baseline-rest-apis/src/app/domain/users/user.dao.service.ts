import { Injectable } from '@nestjs/common';

export class UserDaoService {}
