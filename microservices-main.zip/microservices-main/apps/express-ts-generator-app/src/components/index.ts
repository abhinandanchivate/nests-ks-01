import * as AuthComponent from "./Auth";
import * as UserComponent from "./User";

export { AuthComponent, UserComponent };
