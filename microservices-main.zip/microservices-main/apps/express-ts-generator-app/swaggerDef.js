module.exports = {
  openapi: "3.0.0",
  info: {
    title: "Node-Typescript API",
    version: "1.0.0",
    description: "A sample API",
  },
  servers: [{ url: "http://localhost:3000" }],
};
