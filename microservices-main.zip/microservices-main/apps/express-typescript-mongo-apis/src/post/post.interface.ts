interface Post {
  authorId: string;
  content: string;
  title: string;
}

export default Post;
