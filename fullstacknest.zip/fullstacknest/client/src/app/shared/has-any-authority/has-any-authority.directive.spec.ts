import { HasAnyAuthorityDirective } from './has-any-authority.directive';

describe('HasAnyAuthorityDirective', () => {
  it('should create an instance', () => {
    const directive = new HasAnyAuthorityDirective();
    expect(directive).toBeTruthy();
  });
});
