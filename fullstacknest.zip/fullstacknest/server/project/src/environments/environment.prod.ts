export const environment = {
  production: true,
  secret: 'appsecret123',
  // Expires in 30 min
  expiresIn: 1800000,
  saltOrRounds: 10,
  port: 4000,
};
