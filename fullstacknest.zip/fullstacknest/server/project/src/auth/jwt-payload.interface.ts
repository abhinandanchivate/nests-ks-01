export interface JwtPayload {
  id: string;
  username: string;
  roleName: string;
}
