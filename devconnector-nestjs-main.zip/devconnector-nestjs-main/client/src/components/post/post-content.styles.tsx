import styled from 'styled-components';

export const ContentContainer = styled.div`
  //margin: 2rem 0;
`;
